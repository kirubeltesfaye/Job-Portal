from django.contrib.auth.models import AbstractUser
from django.db import models


class CustomUser(AbstractUser):
    current_location = models.CharField(max_length=50, blank=True,null=True)
    mobile_number = models.CharField(max_length=50, blank=True,null=True)
    education = models.CharField(max_length=50, blank=True,null=True)
    institution = models.CharField(max_length=50, blank=True,null=True)
    about_yourself = models.CharField(max_length=50, blank=True,null=True)
    first_name = models.CharField(max_length=50, blank=True,null=True)
    last_name = models.CharField(max_length=50, blank=True,null=True)
   







