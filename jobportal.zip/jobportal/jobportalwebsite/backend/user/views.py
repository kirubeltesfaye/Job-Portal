from django.shortcuts import render

# Create your views here.

from django.shortcuts import render
from django.contrib.auth.models import User
# Create your views here.

from rest_framework import viewsets
from rest_framework.views import APIView
from django.contrib.auth import login as django_login, logout as django_logout
from rest_framework.authtoken.models import Token

from rest_framework.authentication import TokenAuthentication
from rest_framework.response import Response
from django.views.decorators.csrf import csrf_exempt
from rest_auth.registration.serializers import RegisterSerializer
from rest_auth.registration.views import RegisterView
from rest_framework import serializers
from user.serializer import QuestionSerializer
from rest_framework import generics
from rest_framework import mixins 
from rest_framework.authentication import TokenAuthentication
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from user.models import CustomUser

from user.models import CustomUser
from rest_framework import filters
from rest_auth.serializers import UserDetailsSerializer 
from django.contrib.auth import get_user_model 
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter, SearchFilter
from django_filters import FilterSet
from django_filters import rest_framework as filters
class CustomRegisterView(RegisterView):
    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        custom_data = {"message": "some message", "status": "ok"}
        response.data.update(custom_data)
        return response
class NaRegistrationView(RegisterView):
    serializer_class = CustomRegisterView




class AdJobListView(generics.GenericAPIView,mixins.ListModelMixin,
	mixins.CreateModelMixin,mixins.UpdateModelMixin,mixins.RetrieveModelMixin,mixins.DestroyModelMixin):
	serializer_class = QuestionSerializer
	queryset = CustomUser.objects.all()
	lookup_field = 'username'
	filter_backends = (DjangoFilterBackend,OrderingFilter,SearchFilter)
	filter_fields = ('username', 'is_active',)
	ordering_fields = ('username',)
	search_fields=('username',)
     
     
	


	def get(self,request,username=None):
		if username:
			return self.retrieve(request,username)
		else:
			return self.list(request)

	def post(self,request):
		return self.create(request)
    


	def put(self,request,username=None):

		return self.update(request,username)
	
	def delete(self,request,username=None):
		return self.destroy(request,username)




 







    
    
    







