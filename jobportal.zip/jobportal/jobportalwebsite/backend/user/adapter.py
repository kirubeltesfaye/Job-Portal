from allauth.account.adapter import DefaultAccountAdapter


class CustomAccountAdapter(DefaultAccountAdapter):

    def save_user(self, request, user, form, commit=False):
        user = super().save_user(request, user, form, commit)
        data = form.cleaned_data
        user.current_location = data.get('current_location')
        user.mobile_number = data.get('mobile_number')
        user.education = data.get('education')
        user.institution = data.get('institution')
        user.about_yourself = data.get('about_yourself')
        user.fist_name = data.get('fist_name')
        user.last_name = data.get('last_name')
        
        
        user.save()
        return user