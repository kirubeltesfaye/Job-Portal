from rest_framework import serializers

from allauth.account.adapter import get_adapter
from allauth.account.utils import setup_user_email

from rest_auth.registration.serializers import RegisterSerializer
from rest_auth.registration.views import RegisterView
from rest_framework import serializers
from user.models import CustomUser
class CustomRegisterSerializer(RegisterSerializer):
    current_location = serializers.CharField(
        required=False,
        max_length=50,
    )
    mobile_number = serializers.CharField(
        required=False,
        max_length=50,
    )
    education = serializers.CharField(
        required=False,
        max_length=50,
    )
    institution = serializers.CharField(
        required=False,
        max_length=50,
    )
    about_yourself = serializers.CharField(
        required=False,
        max_length=50,
    )
    first_name = serializers.CharField(
        required=False,
        max_length=50,
    )
    last_name = serializers.CharField(
        required=False,
        max_length=50,
    )
    
    def get_cleaned_data(self):
        data_dict = super().get_cleaned_data()
        data_dict['current_location'] = self.validated_data.get('current_location', '')

        data_dict['mobile_number'] = self.validated_data.get('mobile_number', '')
        data_dict['education'] = self.validated_data.get('education', '')
        data_dict['institution'] = self.validated_data.get('institution', '')
        data_dict['about_yourself'] = self.validated_data.get('about_yourself', '')
        data_dict['first_name'] = self.validated_data.get('first_name', '')
        data_dict['last_name'] = self.validated_data.get('last_name', '')
        
        return data_dict
    
        
class NameRegistrationView(RegisterView):
  serializer_class = CustomRegisterSerializer


class QuestionSerializer(serializers.ModelSerializer):
	class Meta:
		model = CustomUser
		fields =[
		"id",
		"current_location",
		"username",
		"first_name",
		"last_name",
		
		"email",
		"mobile_number",
		"education",
		"institution",
		"about_yourself",

		]


