from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import JsonResponse
# Create your views here.
from jobseeker.serializer import QuestionSerializer
from jobseeker.models import Job
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from rest_framework import mixins 
from rest_framework.authentication import TokenAuthentication
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter, SearchFilter
from django_filters import FilterSet
from django_filters import rest_framework as filters
from rest_framework import status

class AddJobseekerListView(generics.GenericAPIView,mixins.ListModelMixin,
	mixins.CreateModelMixin,mixins.UpdateModelMixin,mixins.RetrieveModelMixin,mixins.DestroyModelMixin):
	serializer_class = QuestionSerializer
	queryset = Job.objects.all()
	lookup_field = 'id'


	authentication_classes = [JSONWebTokenAuthentication]
	permission_classes = [IsAuthenticated]

	filter_backends = (DjangoFilterBackend,OrderingFilter,SearchFilter)
	filter_fields = ('first_name', )
	ordering_fields = ('first_name',)
	search_fields=('^first_name',)


	def get(self,request,id=None):
		if id:
			return self.retrieve(request,id)
		else:
			return self.list(request)

	def post(self,request):
		return self.create(request)
    


	def put(self,request,id=None):

		return self.update(request,id)
	
	def delete(self,request,id=None):
		return self.destroy(request,id)



 
