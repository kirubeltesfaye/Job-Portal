from rest_framework import serializers
from jobseeker.models import Job

class QuestionSerializer(serializers.ModelSerializer):
	class Meta:
		model = Job
		fields =[
		"id",
		"first_name",
		"last_name",
		"current_location",
		"mobile_number",
		"education",
		"institution",
		"about_yourself"]

		
