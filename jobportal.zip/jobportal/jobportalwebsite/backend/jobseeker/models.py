

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Job(models.Model):
	first_name = models.TextField(max_length=50, blank=True)
	last_name = models.TextField(max_length=50, blank=True)
	current_location = models.TextField(max_length=50, blank=True)
	mobile_number = models.TextField(max_length=50, blank=True)
	education = models.TextField(max_length=50, blank=True)
	institution = models.TextField(max_length=50, blank=True)
	about_yourself = models.TextField(max_length=50, blank=True)
    

	

