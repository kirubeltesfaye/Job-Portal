from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import JsonResponse
# Create your views here.

from addjob.serializer import QuestionSerializer
from addjob.models import Job
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import  FormParser,MultiPartParser,JSONParser,FileUploadParser
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from rest_framework import mixins 
from rest_framework.authentication import TokenAuthentication
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response

from django.contrib.auth import get_user_model 
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter, SearchFilter
from django_filters import FilterSet
from django_filters import rest_framework as filters
from rest_framework import status
from .serializer import FileSerializer
class AddJobListView(generics.GenericAPIView,mixins.ListModelMixin,
	mixins.CreateModelMixin,mixins.UpdateModelMixin,mixins.RetrieveModelMixin,mixins.DestroyModelMixin):
	serializer_class = QuestionSerializer
	queryset = Job.objects.all()
	lookup_field = 'id'
	filter_backends = (DjangoFilterBackend,OrderingFilter,SearchFilter)
	filter_fields = ('job_title', )
	ordering_fields = ('job_title',)
	search_fields=('job_title',)

	authentication_classes = [JSONWebTokenAuthentication]
	permission_classes = [IsAuthenticated]


	def get(self,request,id=None):
		if id:
			return self.retrieve(request,id)
		else:
			return self.list(request)

	def post(self,request):
		return self.create(request)
    


	def put(self,request,id=None):

		return self.update(request,id)
	
	def delete(self,request,id=None):
		return self.destroy(request,id)
class UpLoadView(APIView):
	parser_classes =(FileUploadParser,
		)
	

	def post(self,request):
		file = request.data.get('file',None)
		import pdb; pdb.set_trace()
		print(file)
		if file:
			return Response({"message":"file recieved"},status=200)
		else:
			return Response({"message":"File is missing"},status=400)

class FileView(APIView):
  parser_classes = (MultiPartParser, FormParser)
  def post(self, request, *args, **kwargs):
    file_serializer = FileSerializer(data=request.data)
    if file_serializer.is_valid():
      file_serializer.save()
      return Response(file_serializer.data, status=status.HTTP_201_CREATED)
    else:
      return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUEST)




 
