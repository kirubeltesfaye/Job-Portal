from rest_framework import serializers
from addjob.models import Job,File
class QuestionSerializer(serializers.ModelSerializer):
	class Meta:
		model = Job
		fields =[
		"id",
		"job_location",
		"experiance",
		"key_skills",
		"qualification",
		"job_title",
		"functional",
		"job_description"]

class FileSerializer(serializers.ModelSerializer):
  class Meta():
    model = File
    fields = ('file',)