

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Job(models.Model):
	job_location = models.TextField(max_length=50, blank=True)
	experiance = models.TextField(max_length=50, blank=True)
	key_skills = models.TextField(max_length=50, blank=True)
	qualification = models.TextField(max_length=50, blank=True)
	job_title = models.TextField(max_length=50, blank=True)
	functional = models.TextField(max_length=50, blank=True)
	job_description = models.TextField(max_length=50, blank=True)

class File(models.Model):
  file = models.FileField(blank=False, null=False)
  
    

	

