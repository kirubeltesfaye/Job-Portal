
import {Component, OnInit, ViewChild} from '@angular/core';
import {AuthService} from '../services/auth.service';
import {ContactType} from '../shared/feedback';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

import { flyInOut, expand } from '../animations/app.animation';
import {JobseekerService} from '../jobseeker.service';
import { EditProfileService } from '../edit-profile.service';
import {MyStaticClass} from '../shared/login';
import {AddjobService}from '../addjob.service';
@Component({
  selector: 'app-viewjobs',
  templateUrl: './viewjobs.component.html',
  styleUrls: ['./viewjobs.component.scss'],
  host: {
    '[@flyInOut]': 'true',
    'style': 'display: block;',
    '(document:keypress)':'onkey($event)'
  },
  animations: [
    flyInOut(),
    expand()
  ]
})
export class ViewjobsComponent implements OnInit {
user;
submmited;
firstname;
  @ViewChild('fform') feedbackFormDirective;
  message;
  feedbackForm: FormGroup;
  feedback: any;
  contactType = ContactType;
  submitted = null;
  showForm = true;
  blogPosts;
  selectedJob;
  selected;
  x:boolean;
  you;
  jobseeker=[{id:0,current_location:'',mobile_number:'',education:'',institution:'',about_yourself:'',first_name:'',last_name:''}];
  jobrequirement=[{id:0,job_location:'',experiance:'',key_skills:'',qualification:'',job_title:'',functional:'',job_description:''}];
  

  formErrors = {
    'age': '',
    'gender': '',
    'img': '',
    'religion': ''
  };

  validationMessages = {
    'age': {
      'required': 'First Name is required.',
      'minlength': 'First Name must be at least 2 characters long',
      'maxlength': 'First Name cannot be more than 25 characters long'
    },
    'gender': {
      'required': 'Last Name is required.',
      'minlength': 'Last Name must be at least 2 characters long',
      'maxlength': 'Last Name cannot be more than 25 characters long'
    },
    'img': {
      'required': 'Tel. Number is required.'

    },
    'religion': {
      'required': 'Email is required.'

    }
  };

  constructor(private editService: EditProfileService, private fb: FormBuilder,
              private job:AddjobService,private seek:JobseekerService) {
               
                this.getJob();
                this.getUser();
               this.selectedJob= {id:0,job_location:'',experiance:'',key_skills:'',qualification:'',job_title:'',functional:'',job_description:''}
             this.selected=  {id:0,current_location:'',mobile_number:'',education:'',institution:'',about_yourself:'',first_name:'',last_name:''};
              }

  ngOnInit() {

    
    this.createForm();


  }
  createForm() {
    this.feedbackForm = this.fb.group({
      job_location: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      experiance: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
      key_skills: ['', [Validators.required ]],
      qualification: ['', [Validators.required ]],
      job_title: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      functional: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
      job_description: ['', [Validators.required ]],
      agree: false,
      contacttype: 'None',
      body: '',
    });

    this.feedbackForm.valueChanges
      .subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set form validation messages
  }

  onValueChanged(data?: any) {
    if (!this.feedbackForm) { return; }
    const form = this.feedbackForm;

    for (const field in this.formErrors) {
      this.formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }
  onkey(event:KeyboardEvent){
    this.job.search(event.key)
      .subscribe(feedback => {
          this.jobrequirement = feedback;
         

          
        },
        error => console.log(error.status, error.message));
  }



  jobClicked=(job)=>{
   
    this.job.getOneJob(job.id).subscribe(
      data=>{
        
        
        this.selectedJob =data;
        console.log(this.selectedJob);
      },error=>{
        console.log(error);
      }
    )
  }
  getUser=()=>{
   console.log(MyStaticClass.username);
    this.editService.getUserr(MyStaticClass.username).subscribe(profile=>{
      this.selected= profile;
      
      console.log(this.jobseeker);
      
    },error=>{
        console.log(error);
      }
    )
  }
  applyjob=()=>{
    console.log(MyStaticClass.username);
     this.seek.postJobSeeker(this.selected).subscribe(profile=>{
      
       
       console.log(this.jobrequirement);
       
     },error=>{
         console.log(error);
       }
     )
   }
  getJob=()=>{
    this.job.getJob().subscribe(profile=>{
      this.jobrequirement = profile;
      
      console.log(this.jobrequirement);
      
    },error=>{
        console.log(error);
      }
    )
  }
  
/*
  onSubmit() {
    this.feedback = this.feedbackForm.value;
    console.log(this.feedback);
    this.showForm = false;
    this.authService.postProfile(this.feedback)
      .subscribe(feedback => {







        console.log(feedback.gender);

          this.feedback = null;
          setTimeout(() => { this.submitted = null; this.showForm = true; }, 5000);
        },
        error => console.log(error.status, error.message));
    this.feedbackForm.reset({
      age: '',
      gender: '',
      img: '',
      
      agree: false,
      contacttype: 'None',
      body: ''
    });
    this.feedbackFormDirective.resetForm();
  }*/

}

