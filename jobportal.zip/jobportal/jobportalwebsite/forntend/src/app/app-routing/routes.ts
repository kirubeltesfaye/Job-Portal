import { Routes } from '@angular/router';

import { AppComponent } from '../app.component';


import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';




import {AuthGuard} from '../guard/auth.guard';
import {NotAuthGuard} from '../guard/notAuth.guard';


import {EditprofileComponent} from '../editprofile/editprofile.component';
import { JobseekerComponent } from '../jobseeker/jobseeker.component';
import { ViewjobsComponent } from 'app/viewjobs/viewjobs.component';
import { SignupComponent } from 'app/signup/signup.component';
import { AddjobComponent } from 'app/addjob/addjob.component';
export const routes: Routes = [
  
  { path: 'profile',     component: EditprofileComponent , canActivate:[AuthGuard]},
  
  { path: 'signup',     component: SignupComponent  },
  
  {path: 'home',      component: ViewjobsComponent , canActivate:[AuthGuard]},
  {path: 'addjob',      component: AddjobComponent , canActivate:[AuthGuard]},
  {path: 'jobseeker',      component: JobseekerComponent , canActivate:[AuthGuard]},
  { path: '', redirectTo: '/signup', pathMatch: 'full' },
 
  
];
