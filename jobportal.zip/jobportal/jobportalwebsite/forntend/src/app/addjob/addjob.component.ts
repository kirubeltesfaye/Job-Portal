
import {Component, OnInit, ViewChild, HostListener} from '@angular/core';
import {expand, flyInOut} from '../animations/app.animation';
import {ContactType, Feedback} from '../shared/feedback';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';


import {AddjobService}from '../addjob.service';
import {AuthService} from '../services/auth.service';
import { HttpClient } from '@angular/common/http';
import { Key } from 'protractor';
@Component({
  selector: 'app-addjob',
  templateUrl: './addjob.component.html',
  styleUrls: ['./addjob.component.scss'],


  host: {
    '[@flyInOut]': 'true',
    'style': 'display: block;',
    '(document:keypress)':'onkey($event)'
  },
  animations: [
    flyInOut(),
    expand()
  ]
})
export class AddjobComponent implements OnInit {

  @ViewChild('fform') feedbackFormDirective;
  message;
  selectedJob;
  feedbackForm: FormGroup;
  feedback: any;
  contactType = ContactType;
  submitted = null;
  showForm = true;
  blogPosts;
 
  selectedFile:File=null;
  you;
  qualification=['phd','ma degree','ba degree'];
  jobdetail=[{id:0,job_location:'',experiance:'',key_skills:'',qualification:'',job_title:'',functional:'',job_description:''}];
  formErrors = {
    'title': '',
    'lastname': '',
    'password': '',
    'username': ''
  };

  validationMessages = {
    'job_title': {
      'required': 'job_title is required.',
    
    },
    'job_location': {
      'required': 'job location is required.',
     
    },
    'experiance': {
      'required': 'experiance is required.',
      
    },
    'key_skills': {
      'required': 'key skill is required.',
    
    }

  };

  constructor(private fb: FormBuilder,
              private job: AddjobService,private authService:AuthService,private http: HttpClient) { 
                // <--- inject FormBuilder
                
                this.getJobs();
                this.selectedJob={id:0,job_location:'',experiance:'',key_skills:'',qualification:'',job_title:'',functional:'',job_description:''}
                
              }

  ngOnInit() {
    this.createForm();
    
  }

  createForm() {
    this.feedbackForm = this.fb.group({
      job_location: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      experiance: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
      key_skills: ['', [Validators.required ]],
      qualification: ['', [Validators.required ]],
      job_title: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      functional: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
      job_description: ['', [Validators.required ]],
     
      agree: false,
      contacttype: 'None',
      body: '',
    });

    this.feedbackForm.valueChanges
      .subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set form validation messages
  }
  onFileSelected(event){
     this.selectedFile=<File>event.target.files[0];
     console.log(this.selectedFile.name);
  }
 
  onUpload(){
  const fd = new FormData();
  fd.append('image',this.selectedFile,this.selectedFile.name);
    
  
    this.job.image(fd).subscribe(feedback => {
     
      
      
    },
    error => console.log(error.status, error.message));
  }
  onValueChanged(data?: any) {
    if (!this.feedbackForm) { return; }
    const form = this.feedbackForm;

    for (const field in this.formErrors) {
      this.formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }
 
  onkey(event:KeyboardEvent){
    this.job.search(event.key)
      .subscribe(feedback => {
          this.jobdetail = feedback;
         

          
        },
        error => console.log(error.status, error.message));
  }

  onSubmit() {
    this.feedback = this.feedbackForm.value;
    console.log(this.feedback);
    this.showForm = false;
    this.job.postJob(this.feedback)
      .subscribe(feedback => {
          this.submitted = feedback;
          if(this.submitted!=null) {

            
            
            console.log(this.submitted);
          }

          this.feedback = null;
          setTimeout(() => { this.submitted = null; this.showForm = true; }, 5000);
        },
        error => console.log(error.status, error.message));
    this.feedbackForm.reset({
      job_location:'',experiance:'',key_skills:'',qualification:'',job_title:'',functional:'',job_description:''


      
    });
    this.feedbackFormDirective.resetForm();
  }
  
  updateJOb=()=>{
    
    this.job.putJob(this.selectedJob,this.selectedJob.id).subscribe(
      data=>{
       
        this.getJobs();
        
      },error=>{
        console.log(error);
      }
    )
    this.feedbackForm.reset({
      job_location:'',experiance:'',key_skills:'',qualification:'',job_title:'',functional:'',job_description:''
    });
    
  }
  jobClicked=(job)=>{
   
    this.job.getOneJob(job.id).subscribe(
      data=>{
        
        
        this.selectedJob =data;
        console.log(this.selectedJob);
      },error=>{
        console.log(error);
      }
    )
  }
  getJobs=()=>{
    this.job.getJob().subscribe(profile=>{
      this.jobdetail = profile;
      console.log(this.selectedJob);
      console.log(this.jobdetail);
      
      
    },error=>{
        console.log(error);
      }
    )
  }
  deleteJObs=()=>{
    this.job.deleteJOb(this.selectedJob.id).subscribe(
      data=>{
        this.getJobs();
      },error=>{ 
        console.log(error);
      }
    )
    this.feedbackForm.reset({
      ob_location:'',experiance:'',key_skills:'',qualification:'',job_title:'',functional:'',job_description:''
    });
  }
  
  


}
