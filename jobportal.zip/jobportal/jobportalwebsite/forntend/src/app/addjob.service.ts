import { Injectable } from '@angular/core';

import {Http,Headers, RequestOptions} from "@angular/http";

import {Observable} from "rxjs/Observable";

import 'rxjs/add/operator/map';
import {HttpHeaders} from "@angular/common/http";
import {tokenNotExpired} from 'angular2-jwt';
import {AuthService} from './services/auth.service';
@Injectable()
export class AddjobService {
  options;

  createAuthenticationHeaders() {
    this.authService.loadToken();
    this.options = new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        'Authorization': 'JWT '+this.authService.authToken
        
      })
    });

  }



  constructor(private authService:AuthService,private http:Http) { }
  getJob(): Observable<any>{
  
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/addjob/',this.options).map(res=>res.json());
  }
  
 
  postJob(profile): Observable<any>{
    const body = {job_location:profile.job_location,experiance:profile.experiance,key_skills:profile.key_skills,qualification:profile.qualification,job_title:profile.job_title,functional:profile.functional,job_description:profile.job_description};
    this.createAuthenticationHeaders();
    return this.http.post('http://192.168.43.163:8000/' + 'addjob/', body,this.options).map(res=>res.json());
  }
  putJob(profile,user): Observable<any>{
    const body = {job_location:profile.job_location,experiance:profile.experiance,key_skills:profile.key_skills,qualification:profile.qualification,job_title:profile.job_title,functional:profile.functional,job_description:profile.job_description};
    this.createAuthenticationHeaders();
    return this.http.put('http://192.168.43.163:8000/' + 'addjob/'+user+'/', body,this.options).map(res=>res.json());
  }
  getOneJob(id):Observable<any>{
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/addjob/'+id+'/',this.options).map(res=>res.json());
  }
  deleteJOb(id):Observable<any>{
    this.createAuthenticationHeaders();
    return this.http.delete( 'http://192.168.43.163:8000/addjob/'+ id+'/',this.options).map(res=>res.json());

    }
  image(upload){
    this.createAuthenticationHeaders();
    return this.http.post('http://192.168.43.163:8000/' + 'uploadd/',upload,this.options).map(res=>res.json());

  }
  search(key){
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/' + 'addjob/?search='+key,this.options).map(res=>res.json());

  }
  
}
