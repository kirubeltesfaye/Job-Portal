import { TestBed, inject } from '@angular/core/testing';

import { JobseekerService } from './jobseeker.service';

describe('JobseekerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [JobseekerService]
    });
  });

  it('should be created', inject([JobseekerService], (service: JobseekerService) => {
    expect(service).toBeTruthy();
  }));
});
