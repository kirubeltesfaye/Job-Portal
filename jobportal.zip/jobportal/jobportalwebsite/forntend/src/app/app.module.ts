import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatButtonModule, MatCheckboxModule, MatDatepickerModule, MatFormFieldModule,
  MatInputModule, MatRadioModule, MatSelectModule, MatSliderModule,
  MatSlideToggleModule, MatToolbarModule, MatListModule, MatGridListModule,
  MatCardModule, MatIconModule, MatProgressSpinnerModule, MatDialogModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ReactiveFormsModule } from '@angular/forms';
import {AuthGuard} from './guard/auth.guard';

import {MatExpansionModule} from '@angular/material/expansion'; 
import 'hammerjs';

import { AppComponent } from './app.component';


import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';


import { LoginComponent } from './login/login.component';

import {NotAuthGuard} from './guard/notAuth.guard';

import { AuthService } from './services/auth.service';



import { AppRoutingModule } from './app-routing/app-routing.module';

import { baseURL } from './shared/baseurl';

import { RestangularModule, Restangular } from 'ngx-restangular';
import { RestangularConfigFactory } from './shared/restConfig';
import { HighlightDirective } from './directives/highlight.directive';
import {HTTP_INTERCEPTORS} from '@angular/common/http';

import 'reflect-metadata';
import 'zone.js';



import {FileUploadModule} from 'ng2-file-upload';
import {AddjobService}from './addjob.service';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { EditProfileService } from './edit-profile.service';
import { JobseekerComponent } from './jobseeker/jobseeker.component';
import {JobseekerService} from './jobseeker.service'
import {MatTabsModule} from '@angular/material/tabs';
import {MatTableModule} from '@angular/material/table'; 
import {MatRippleModule} from '@angular/material/core'; 
import {MatAutocompleteModule} from '@angular/material/autocomplete'; 
import {MatMenuModule} from '@angular/material/menu';
import { ViewjobsComponent } from './viewjobs/viewjobs.component';
import { SignupComponent } from './signup/signup.component';
import { AddjobComponent } from './addjob/addjob.component'; 
@NgModule({
  declarations: [
    AppComponent,
 
    
    HeaderComponent,
    FooterComponent,
   
  
    LoginComponent,
    HighlightDirective,
    
    
   
    
    EditprofileComponent,
    JobseekerComponent,
    ViewjobsComponent,
    SignupComponent,
    AddjobComponent,
    
  ],
  imports: [
    BrowserModule, FileUploadModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatMenuModule,
    FormsModule,
    HttpClientModule,
    MatButtonModule, MatCheckboxModule, MatDatepickerModule, MatFormFieldModule,
    MatInputModule, MatRadioModule, MatSelectModule, MatSliderModule,
    MatSlideToggleModule, MatToolbarModule, MatListModule, MatGridListModule,
    MatCardModule, MatIconModule, MatProgressSpinnerModule, MatDialogModule,
    FlexLayoutModule,
    AppRoutingModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatRippleModule,
    RestangularModule.forRoot(RestangularConfigFactory)
  ],
  providers: [
   
    AuthGuard,
    NotAuthGuard,
    
    AddjobService,
    JobseekerService,
    
    EditProfileService,
    
    
    { provide: 'BaseURL', useValue: baseURL },
    
    AuthService,
   


  ],
  entryComponents: [
        LoginComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
