
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AuthService } from '../services/auth.service';
import { Feedback, ContactType } from '../shared/feedback';
import { flyInOut, expand } from '../animations/app.animation';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
  host: {
  '[@flyInOut]': 'true',
  'style': 'display: block;'
  },
  animations: [
    flyInOut(),
    expand()
  ]
})
export class SignupComponent implements OnInit {

  @ViewChild('fform') feedbackFormDirective;
  message;
  feedbackForm: FormGroup;
  feedback: Feedback;
  contactType = ContactType;
  submitted = null;
  showForm = true;
  educationn=['ma degree','ba degree','highshcool degree'];
  institution=['AAU','BDU','HW','JU','AU'];
  formErrors = {
    'first_name': '',
    'last_name': '',
    'password1': '',
    'password2': '',

    'username': '',
    'email':'',
    'mobile_number':'',
    'current_location':''
  };

  validationMessages = {
    'first_name': {
      'required': 'First Name is required.',
      'minlength': 'First Name must be at least 2 characters long',
      'maxlength': 'First Name cannot be more than 25 characters long'
    },
    'last_name': {
      'required': 'Last Name is required.',
      'minlength': 'Last Name must be at least 2 characters long',
      'maxlength': 'Last Name cannot be more than 25 characters long'
    },
    'password1': {
      'required': 'password is required',
      'minlength': 'password must be at lease 8 characters',

    },
    'password2': {
      'required': 'password is required',
      'minlength': 'password must be at lease 8 characters',

    },
    'username': {
      'required': 'username is required.',
      
    }, 
    'email': {
      'required': 'email is required.',
      'email':'invalid email'
    },
    'mobile_number': {
      'required': 'mobile no is required.',
      
    },
    'current_location': {
      'required': 'current location is required.',
      
    },
   

  };

  constructor(private fb: FormBuilder,
    private authService: AuthService) { // <--- inject FormBuilder
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.feedbackForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      email: ['', [Validators.required, Validators.email ]],
      first_name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      last_name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
      current_location: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      mobile_number: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
     
      password1: ['', [Validators.required,Validators.minLength(8) ]],
      password2: ['', [Validators.required ,Validators.minLength(8)]],
     
      agree: false,
      education: 'phd',
      institution: 'AAU',
      about_yourself:'',
      message: '',
    });

    this.feedbackForm.valueChanges
      .subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set form validation messages
  }

  onValueChanged(data?: any) {
    if (!this.feedbackForm) { return; }
    const form = this.feedbackForm;

    for (const field in this.formErrors) {
      this.formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  onSubmit() {
    this.feedback = this.feedbackForm.value;
    console.log(this.feedback);
    this.showForm = false;
    this.authService.postUser(this.feedback)
      .subscribe(feedback => {
         this.submitted = feedback;
          if(!this.submitted.success) {

            this.message = this.submitted.message;
          }

          this.feedback = null;
         setTimeout(() => { this.submitted = null; this.showForm = true; }, 5000);
        },
        error => console.log(error.status, error.message));
    this.feedbackForm.reset({
      username: '',
      email: '',
      password1: '',
      password2: '',
      agree: false,
      contacttype: 'None',
      message: ''
    });
    this.feedbackFormDirective.resetForm();
  }

}

