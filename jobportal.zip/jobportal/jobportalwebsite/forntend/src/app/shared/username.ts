export class MyStaticClasss {
    public static username : string;
   
  
   
  }