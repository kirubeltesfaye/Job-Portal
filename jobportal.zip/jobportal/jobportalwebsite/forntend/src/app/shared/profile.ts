export class Profile{

  age: number;
  img: string;
  gender: string;
  religion: string;



};
