export class User {
    _id: string;
    username: string;
    firstname: string;
    lastname: string;
    facebookId: string;
    admin: boolean;
}