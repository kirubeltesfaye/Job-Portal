export class MyStaticClass {
  public static admin : boolean=false;
  public static staff : boolean=false;
  public static username : string;

 
}