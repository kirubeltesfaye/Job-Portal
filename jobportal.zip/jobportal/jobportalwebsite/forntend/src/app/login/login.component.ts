import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, AnimationDurations} from '@angular/material';
import { AuthService } from '../services/auth.service';
import {jsonpFactory} from '@angular/http/src/http_module';
import {MyStaticClasss} from '../shared/username';
import {MyStaticClass} from '../shared/login';
import {Router} from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  submitted = null;

  user = {username: '', password: ''};
  errMess: string;
  
  


  constructor(public dialogRef: MatDialogRef<LoginComponent>,
    private authService: AuthService ,private router: Router) { }

  ngOnInit() {
  }

  onSubmit() {
    console.log("User: ", this.user);
    this.authService.what(this.user)
      .subscribe(res => {
        this.submitted = res;
       
      

        if (this.submitted!=null) {
          this.authService.storeUserData(this.submitted.token, this.submitted.user.username);

          
          if(this.submitted.user.username=="methebest"){
            
            MyStaticClass.admin=true;
            this.dialogRef.close(true);
            this.router.navigate(['/jobseeker']);
          }
         else{
           
          MyStaticClass.username= this.submitted.user.username;
          MyStaticClass.admin=false
          this.dialogRef.close(true);
          this.router.navigate(['/home']);
         }
         console.log(MyStaticClass.username);
         
          console.log(this.submitted);
          console.log(MyStaticClass.admin);
          console.log(this.authService.login());
          
        
         
         


        }

      },
      error => {
        console.log(error);
        this.errMess = error
      })
  }
  
  

}
