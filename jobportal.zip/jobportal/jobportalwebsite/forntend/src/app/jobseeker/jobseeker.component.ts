import {Component, OnInit, ViewChild, HostListener} from '@angular/core';
import {expand, flyInOut} from '../animations/app.animation';
import {ContactType, Feedback} from '../shared/feedback';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';


import {AddjobService}from '../addjob.service';
import {AuthService} from '../services/auth.service';
import { HttpClient } from '@angular/common/http';
import { Key } from 'protractor';
import {JobseekerService} from '../jobseeker.service'

@Component({
  selector: 'app-jobseeker',
  templateUrl: './jobseeker.component.html',
  styleUrls: ['./jobseeker.component.scss'],
  host: {
    '[@flyInOut]': 'true',
    'style': 'display: block;',
    '(document:keypress)':'onkey($event)'
  },
  animations: [
    flyInOut(),
    expand()
  ]
})
export class JobseekerComponent implements OnInit {

  @ViewChild('fform') feedbackFormDirective;
  message;
  selectedJOb;
  feedbackForm: FormGroup;
  feedback: any;
  contactType = ContactType;
  submitted = null;
  showForm = true;
  blogPosts;
 
  selectedFile:File=null;
  you;
  qualification=['phd','ma degree','ba degree'];
  jobseeker=[{id:0,current_location:'',mobile_number:'',education:'',institution:'',about_yourself:'',first_name:'',last_name:''}];
  formErrors = {
    'title': '',
    'lastname': '',
    'password': '',
    'username': ''
  };

  validationMessages = {
    'title': {
      'required': 'First Name is required.',
      'minlength': 'First Name must be at least 2 characters long',
      'maxlength': 'First Name cannot be more than 25 characters long'
    },
    'lastname': {
      'required': 'Last Name is required.',
      'minlength': 'Last Name must be at least 2 characters long',
      'maxlength': 'Last Name cannot be more than 25 characters long'
    },
    'password': {
      'required': 'Tel. Number is required.'

    },
    'username': {
      'required': 'Email is required.',
      'email': 'Email not in valid format'
    }
  };

  constructor(private fb: FormBuilder,
              private addjob: JobseekerService,private authService:AuthService,private http: HttpClient) { 
                // <--- inject FormBuilder
                this.submitted;
                this.getJobSeeker();
                this.selectedJOb={id:0,current_location:'',mobile_number:'',education:'',institution:'',about_yourself:'',first_name:'',last_name:''}
                
                
              }

  ngOnInit() {
    this.createForm();
    
  }

  createForm() {
    this.feedbackForm = this.fb.group({
      current_location: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      mobile_number: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
      education: ['', [Validators.required ]],
      institution: ['', [Validators.required ]],
      about_yourself: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ]],
      first_name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25) ] ],
      last_name: ['', [Validators.required ]],
     
      agree: false,
      contacttype: 'None',
      body: '',
    });

    this.feedbackForm.valueChanges
      .subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set form validation messages
  }/*
  onFileSelected(event){
     this.selectedFile=<File>event.target.files[0];
     console.log(this.selectedFile.name);
  }
 
  onUpload(){
  const fd = new FormData();
  fd.append('image',this.selectedFile,this.selectedFile.name);
    
  
    this.addjob.image(fd).subscribe(feedback => {
     
      
      
    },
    error => console.log(error.status, error.message));
  }*/
  onValueChanged(data?: any) {
    if (!this.feedbackForm) { return; }
    const form = this.feedbackForm;

    for (const field in this.formErrors) {
      this.formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  onkey(event:KeyboardEvent){
    this.addjob.search(event.key)
      .subscribe(feedback => {
          this.jobseeker = feedback;
         

          
        },
        error => console.log(error.status, error.message));
  }
/*
  onSubmit() {
    this.feedback = this.feedbackForm.value;
    console.log(this.feedback);
    this.showForm = false;
    this.addjob.postProfile(this.feedback)
      .subscribe(feedback => {
          this.submitted = feedback;
          if(this.submitted!=null) {

            
            
            console.log(this.submitted);
          }

          this.feedback = null;
          setTimeout(() => { this.submitted = null; this.showForm = true; }, 5000);
        },
        error => console.log(error.status, error.message));
    this.feedbackForm.reset({
      title: '',
      lastname: '',
      password: '',
      username: '',
      agree: false,
      contacttype: 'None',
      body: ''
    });
    this.feedbackFormDirective.resetForm();
  }
  
  updateMovie=()=>{
    
    this.addjob.putProfile(this.selectedMovie).subscribe(
      data=>{
       
        this.getMovies();
        
      },error=>{
        console.log(error);
      }
    )
    
  }*/

  jobClicked=(job)=>{
  
    this.addjob.getOneJobSeeker(job.id).subscribe(
      data=>{
        this.selectedJOb = data;
        console.log(this.selectedJOb);
      },error=>{
        console.log(error);
      }
    )
  }  /*
  getMovies=()=>{
    this.authService.getProfile().subscribe(profile=>{
      this.movies = profile;
     
      
    },error=>{
        console.log(error);
      }
    )
  }*/
  getJobSeeker=()=>{
  
    this.addjob.getJobSeeker().subscribe(
      data=>{
        this.jobseeker = data;
        console.log(this.jobseeker);
      },error=>{
        console.log(error);
      }
    )
  }
  



}
