import { Injectable } from '@angular/core';
import {Http,Headers, RequestOptions} from "@angular/http";
import {baseURL} from "../shared/baseurl";
import {Feedback} from "../shared/feedback";
import {Observable} from "rxjs/Observable";
import {MyStaticClass} from '../shared/login';
import 'rxjs/add/operator/map';
import {HttpHeaders} from "@angular/common/http";
import {tokenNotExpired} from 'angular2-jwt';
import {Profile} from '../shared/profile';
import { LoginComponent } from '../login/login.component';
import {MatDialog, MatDialogRef, AnimationDurations} from '@angular/material';
@Injectable()
export class AuthService {

  authToken;
  user;
  userr;
  options;
auth : AuthService
dialogRef: MatDialogRef<LoginComponent>
  
 



  constructor(private http:Http) { }
  
  createAuthenticationHeaders(){
    this.loadToken();
    this.options = new RequestOptions({
      headers: new Headers({
        'Content-Type':'application/json',
        'Authorization':'JWT '+this.authToken
      })
    });

  }
  
  loadToken(){
    const token = localStorage.getItem('token');
    this.authToken = token;

  }

  what(user): Observable<any>{
    const body = {username:user.username,password:user.password};
    return this.http.post('http://192.168.43.163:8000/' +'rest-auth/login/',body).map(res=>res.json());
    

    
    
  }
  
  login(){
    return MyStaticClass.admin;
  }
  
  logout(){
    this.authToken = null;  
    this.user = null;

    localStorage.clear();

  }

  storeUserData(token,user){
    localStorage.setItem('token',token);
    localStorage.setItem('user',JSON.stringify(user));
    this.authToken = token;
    this.user= user;

  }

  getProfile(){
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/addjob/',this.options).map(res=>res.json());


  }

  getProfiles(){

    return this.http.get(baseURL+'users').map(res=>res.json());


  }

  postProfile(profile): Observable<Profile>{
    const body = {title:profile.title,status:profile.status,created_by:profile.created_by,first_name:profile.first_name,last_name:profile.last_name};
    this.createAuthenticationHeaders();
    return this.http.post('http://192.168.43.163:8000/' + 'poll/', body,this.options).map(res=>res.json());
  }
  postUser(profile): Observable<Profile>{
    const body = {username:profile.username,email:profile.email,password1:profile.password1,password2:profile.password2,first_name:profile.first_name,last_name:profile.last_name,current_location:profile.current_location,mobile_number:profile.mobile_number,education:profile.education,institution:profile.institution,about_yourself:profile.about_yourself};
    
    return this.http.post('http://192.168.43.163:8000/' + 'registration/', body).map(res=>res.json());
  }
  editUser(profile): Observable<Profile>{
    const body = {username:profile.username,email:profile.email,password1:profile.password1,password2:profile.password2,first_name:profile.first_name,last_name:profile.last_name,current_location:profile.current_location,mobile_number:profile.mobile_number,education:profile.education,insitution:profile.insitution,about_yourself:profile.about_yourself};
    
    return this.http.put('http://192.168.43.163:8000/' + 'rest-auth/registration/', body).map(res=>res.json());
  }

  loggedIn(){
  return tokenNotExpired();
  }


  getLoggedInUser() {
    return JSON.parse(localStorage.getItem('user'));
  }
 

}

