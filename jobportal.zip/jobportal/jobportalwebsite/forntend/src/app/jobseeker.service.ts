import { Injectable } from '@angular/core';

import {Http,Headers, RequestOptions} from "@angular/http";

import {Observable} from "rxjs/Observable";

import 'rxjs/add/operator/map';
import {HttpHeaders} from "@angular/common/http";
import {tokenNotExpired} from 'angular2-jwt';
import {AuthService} from './services/auth.service';

@Injectable()
export class JobseekerService {

  options;

  createAuthenticationHeaders() {
    this.authService.loadToken();
    this.options = new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        'Authorization': 'JWT '+this.authService.authToken
        
      })
    });

  }



  constructor(private authService:AuthService,private http:Http) { }
  postJobSeeker(profile): Observable<any>{
    const body = {current_location:profile.current_location,mobile_number:profile.mobile_number,education:profile.education,institution:profile.institution,about_yourself:profile.about_yourself,first_name:profile.first_name,last_name:profile.last_name};
    this.createAuthenticationHeaders();
    return this.http.post('http://192.168.43.163:8000/' + 'jobseeker/', body,this.options).map(res=>res.json());
  }
  putJobSeeker(profile): Observable<any>{
    const body = {current_location:profile.current_location,mobile_number:profile.mobile_number,education:profile.education,institution:profile.institution,about_yourself:profile.about_yourself,first_name:profile.first_name,last_name:profile.last_name};
    this.createAuthenticationHeaders();
    return this.http.put('http://192.168.43.163:8000/' + 'jobseeker/'+profile.id+'/', body,this.options).map(res=>res.json());
  }
  getJobSeeker():Observable<any>{
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/jobseeker/',this.options).map(res=>res.json());
  }
  getOneJobSeeker(id):Observable<any>{
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/jobseeker/'+id+'/',this.options).map(res=>res.json());
  }
  search(user): Observable<any>{
  
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/jobseeker/?search='+user,this.options).map(res=>res.json());
  }
  

}
