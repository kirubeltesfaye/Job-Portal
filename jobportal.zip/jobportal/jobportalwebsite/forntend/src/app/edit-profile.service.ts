import { Injectable } from '@angular/core';

import {Http,Headers, RequestOptions} from "@angular/http";

import {Observable} from "rxjs/Observable";

import 'rxjs/add/operator/map';
import {HttpHeaders} from "@angular/common/http";
import {tokenNotExpired} from 'angular2-jwt';
import {AuthService} from './services/auth.service';

@Injectable()
export class EditProfileService {
  options;

  createAuthenticationHeaders() {
    this.authService.loadToken();
    this.options = new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        'Authorization': 'JWT '+this.authService.authToken
      })
    });

  }




 
  
  constructor(private authService:AuthService,private http:Http) { }
  
  editUser(profile,user): Observable<any>{
    this.createAuthenticationHeaders();
    const body = {username:profile.username,email:profile.email,current_location:profile.current_location,mobile_number:profile.mobile_number,first_name:profile.first_name,last_name:profile.last_name,education:profile.education,insitution:profile.insitution,about_yourself:profile.about_yourself};
    
    return this.http.put('http://192.168.43.163:8000/' + 'registrationnn/'+user+'/', body,this.options).map(res=>res.json());
  }
  
  getUser(){
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/' + 'rest-auth/user/',this.options).map(res=>res.json());


  }
  getUserr(user){
    this.createAuthenticationHeaders();
    return this.http.get('http://192.168.43.163:8000/' + 'registrationnn/'+user+'/',this.options).map(res=>res.json());


  }
}
